package com.paragon.netapp.tests;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

import com.paragaon.netapp.dicoverModule.DiscoverReports;



public class DiscoverReportTest extends BaseTest{
	
	@Test(priority=5)
	public void callMeTest() throws InterruptedException {
	
		// calling Page reach method bcoz it contains the common step to reach till the discover page 
		DiscoverReports d1 = new DiscoverReports();
			d1.pageReach(driver);
			d1.callMeReport(driver);
	 }

    @Test(priority=6)      
    public void uknownOwnerReport() throws InterruptedException {
    	Thread.sleep(5000);
    	DiscoverReports d1 = new DiscoverReports();
		d1.pageReach(driver);
		d1.unknownOwnerReport(driver);
    	
    }
    
    @Test(priority=7)
	public void volumeDecommisionReport() throws InterruptedException {
    	Thread.sleep(5000);
    	DiscoverReports d1 = new DiscoverReports();
		d1.pageReach(driver);
		d1.volumeDecommision(driver);
    	
    }
    @Test(priority=8)
	public void multiOwnerReport() throws InterruptedException {
    	Thread.sleep(5000);
    	DiscoverReports d1 = new DiscoverReports();
		d1.pageReach(driver);
		d1.multiOwner(driver);
    	
    }
    @Test(priority=9)
	public void activityReport() throws InterruptedException {
    	Thread.sleep(5000);
    	DiscoverReports d1 = new DiscoverReports();
		d1.pageReach(driver);
		d1.activityReport(driver);
    	
    }
    @Test(priority=10)
	public void applicationDetailReport() throws InterruptedException {
    	Thread.sleep(5000);
    	DiscoverReports d1 = new DiscoverReports();
		d1.pageReach(driver);
		d1.applicationDetail(driver);
    	
    }
    
    
}
 



