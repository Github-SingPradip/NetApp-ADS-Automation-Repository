package com.paragaon.netapp.dicoverModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ControlRelease {
	
	public static void ControlBatch(WebDriver driver,String SourceController) throws InterruptedException {
		driver.findElement(By.linkText("Discover")).click();
		Thread.sleep(5000);
		driver.findElement(By.partialLinkText("Controller Release")).click();

		driver.findElement(By.xpath(".//div/div/div[1]/div[2]/div/button")).click();

		Thread.sleep(5000);

		WebElement autoOptions= driver.findElement(By.name("controllerName"));

		autoOptions.sendKeys(SourceController);
		Thread.sleep(5000);
		autoOptions.sendKeys(Keys.TAB);

		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"createNewControllerRelease\"]/div/app-controller-release-create/form/button")).click();

		Thread.sleep(5000);
		
	}
	
	public static void DeleteRelease(WebDriver driver) throws InterruptedException {
		
		driver.findElement(By.linkText("Discover")).click();
		Thread.sleep(5000);
		driver.findElement(By.partialLinkText("Controller Release")).click();
		driver.findElement(By.xpath("(.//*[@class='btn btn-sm btn-warning'])[1]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@class='modal-footer']//*[text()='Delete']")).click();
		Thread.sleep(5000);
		driver.findElement(By.linkText("Discover")).click();
		Thread.sleep(5000);
		driver.findElement(By.partialLinkText("Controller Work Packages")).click();
		driver.findElement(By.xpath("(.//*[@class='btn btn-sm btn-warning'])[1]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@class='modal-footer']//*[text()='Delete']")).click();
		Thread.sleep(5000);
			}
	}
