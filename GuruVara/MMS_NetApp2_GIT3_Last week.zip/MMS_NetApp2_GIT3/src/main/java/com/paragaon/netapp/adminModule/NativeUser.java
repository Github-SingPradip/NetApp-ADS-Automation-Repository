package com.paragaon.netapp.adminModule;

import java.sql.ResultSet;
import java.util.List;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.paragon.netapp.projectUtils.DatabaseManager;

public class NativeUser {
	public static void newUserCreation(WebDriver driver, String username, String firstname, String lastname,
			String password, String confirmpassword, String email, String role, String enabled) throws Exception {

		Thread.sleep(3000);
		driver.findElement(By.linkText("Admin")).click();
		driver.findElement(By.xpath("//*[text()='Native User Management']")).click();
		driver.findElement(By.xpath("//button[text()='Add User']")).click();

		Thread.sleep(3000);
		driver.findElement(By.name("userName")).clear();
		driver.findElement(By.name("userName")).sendKeys(username);
		Thread.sleep(5000);
		driver.findElement(By.name("firstName")).clear();
		driver.findElement(By.name("firstName")).sendKeys(firstname);
		Thread.sleep(5000);
		driver.findElement(By.name("lastName")).clear();
		driver.findElement(By.name("lastName")).sendKeys(lastname);
		Thread.sleep(5000);
		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("passwordConfirm")).clear();
		driver.findElement(By.name("passwordConfirm")).sendKeys(confirmpassword);
		Thread.sleep(5000);
		driver.findElement(By.name("email")).clear();
		driver.findElement(By.name("email")).sendKeys(email);
		Select dropdown = new Select(driver.findElement(By.name("userRole")));
		dropdown.selectByVisibleText(role);
		Select dropdown1 = new Select(driver.findElement(By.name("user.enabled")));
		dropdown1.selectByVisibleText(enabled);

		driver.findElement(By.xpath("//*[@class='modal-footer']//*[text()='Create User']")).click();

		Thread.sleep(3000);

		ResultSet rs = DatabaseManager.verifyUserinDB(username);

		while (rs.next()) {
			System.out.println("xl------------------------>DB");
			System.out.println(username + "------------------->" + rs.getString("user_name"));
			System.out.println(firstname + "------------------->" + rs.getString("first_name"));
			System.out.println(lastname + "------------------->" + rs.getString("last_name"));
			System.out.println(role + "------------------->" + rs.getString("user_role_id"));
			System.out.println(enabled + "------------------->" + rs.getString("enabled"));
			System.out.println(email + "------------------->" + rs.getString("email"));

			// Verifying in DB with each record added.
			if (username.equals(rs.getString("user_name")) && firstname.equals(rs.getString("first_name"))
					&& lastname.equals(rs.getString("last_name")) && role.equals(rs.getString("user_role_id"))
					&& enabled.equals(rs.getString("enabled")) && email.equals(rs.getString("email"))) {
				System.out.println("*********************Created User is present in Database**********************");
			} else {
				Assert.assertTrue(false);
			}
		}
	}

	public static void editUser(WebDriver driver, String username, String firstname, String lastname, String password,
			String confirmpassword, String email, String role, String enabled) throws Exception {
		Thread.sleep(2000);
		driver.findElement(By.linkText("Admin")).click();
		driver.findElement(By.xpath("//*[text()='Native User Management']")).click();

		WebElement wb = driver.findElement(By.xpath("//a[contains(@aria-label,'go to next page')]"));
		boolean found = false;
		while (wb.isEnabled()) {
			List<WebElement> allNames = driver
					.findElements(By.xpath("//datatable-body-row/div/datatable-body-cell[1]/div/span"));

			for (int i = 0; i < allNames.size(); i++) {
				Thread.sleep(1000);

				System.out.println(allNames.get(i).getText());

				if (allNames.get(i).getText().equals(username)) {
					driver.findElement(By.xpath("//datatable-body-cell[div[span[text()='" + username
							+ "']]]/following-sibling::datatable-body-cell/div/button[1]")).click();
					found = true;
				}

			}
			if (found == false) {
				wb.click();
			}

		}

		if (firstname != "0") {
			driver.findElement(By.name("firstName")).clear();
			driver.findElement(By.name("firstName")).sendKeys(firstname);
		}

		if (lastname != "0") {
			driver.findElement(By.name("lastName")).clear();
			driver.findElement(By.name("lastName")).sendKeys(lastname);
		}
		if (email != "0") {
			driver.findElement(By.name("email")).clear();
			driver.findElement(By.name("email")).sendKeys(email);
		}
		if (role != "0") {
			WebElement wb1 = driver.findElement(By.name("userRoleId"));
			Select s = new Select(wb1);
			s.selectByValue(role);
		}
		if (enabled != "0") {
			WebElement wb2 = driver.findElement(By.name("User.enabled"));
			Select s = new Select(wb2);
			s.selectByValue(enabled);
		}

		driver.findElement(By.xpath("//button[text()='Save']")).click();
	}

	public static void deleteUser(WebDriver driver, String username, String firstname, String lastname, String password,
			String confirmpassword, String email, String role, String enabled) throws Exception {
		Thread.sleep(2000);
		driver.findElement(By.linkText("Admin")).click();
		driver.findElement(By.xpath("//*[text()='Native User Management']")).click();

		// Clicking on pagination right button(datatable-icon-right).
		WebElement wb = driver.findElement(By.xpath("//a[contains(@aria-label,'go to next page')]"));
		boolean found = false;

		while (!found) // While Not Found.
		{
			while (wb.isEnabled()) // and 'datatable-icon-right' arrow is enabled means still item are left in
									// right side.
			{
				List<WebElement> allNames = driver
						.findElements(By.xpath("//datatable-body-row/div/datatable-body-cell[1]/div/span"));

				for (int i = 0; i < allNames.size(); i++) {
					Thread.sleep(1000);

					System.out.println(allNames.get(i).getText());

					if (allNames.get(i).getText().equals(username)) {
						found = true;
						break;
					}

				}
				
				  if(found==false) { wb.click(); }
				 
				else if(found==true) { break; }
				

			}
			if (found == true) {
//driver.findElement(By.xpath("//datatable-body-cell[div[span[text()='"+username+"']]]/following-sibling::datatable-body-cell/div/button[@class='btn btn-sm btn-danger']")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//button[text()='Delete']")).click();
			}
		}

		ResultSet rs = DatabaseManager.verifyUserinDB(username);
		if (rs.next()) {
			System.out.println("Something went wrong");
		} else {
			System.out.println("No Record found in Database");
		}

	}
}
