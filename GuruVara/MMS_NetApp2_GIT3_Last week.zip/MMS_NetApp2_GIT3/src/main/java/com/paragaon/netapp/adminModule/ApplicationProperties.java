package com.paragaon.netapp.adminModule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class ApplicationProperties {
	
	public static void ApplicationProp(WebDriver driver) throws InterruptedException {
		
		 Thread.sleep(5000);
        driver.findElement(By.xpath(".//*[@id='adminDropdown']")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath(".//*[text()='Application Properties']")).click();
        driver.switchTo().parentFrame();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[text()='Core']")).click();
        
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[text()='WFA']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[text()='Rules']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[text()='Jobs']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[text()='Core']")).click();
        Thread.sleep(2000);

        WebElement getelement = driver.findElement(By.xpath(".//*[@name='pagesPerPage']"));
        Select selectrow = new Select(getelement);
        // dropdown.selectByVisibleText(selectedPreference);
        selectrow.selectByValue("1");
        Thread.sleep(5000);
	}
}
