package com.paragon.netapp.tests;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.paragaon.netapp.adminModule.NativeUser;
import com.paragon.netapp.projectUtils.XLUtility;

public class NativeTest extends BaseTest {
	
	@Test(dataProvider="TestUserScenarios",priority=2)
	
	public void userTest(String Action,String username,String firstname,String lastname,String password,String confirmpassword,String email,String role,String enabled) throws Exception
	{
		if(Action.equalsIgnoreCase("Create"))
		{
			NativeUser.newUserCreation(driver,username,firstname,lastname,password,confirmpassword,email,role,enabled);
		}	
		
		else if(Action.equalsIgnoreCase("Edit"))
		{
			NativeUser.editUser(driver,username,firstname,lastname,password,confirmpassword,email,role,enabled);
		}
		else if(Action.equalsIgnoreCase("Delete"))
		{
			NativeUser.deleteUser(driver, username, firstname, lastname, password, confirmpassword, email, role, enabled);
		}
		
	}
		@DataProvider(name="TestUserScenarios")
		public String[][] getData1() throws Exception
		{
			String[][] data=XLUtility.getData("TestUserScenarios","TestData.xls");
			
			return data;

		}

}
